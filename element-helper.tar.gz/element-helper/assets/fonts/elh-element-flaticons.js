{
    "icons" = [
        "flaticon-heart-1",
        "flaticon-24-hours-support",
        "flaticon-email",
        "flaticon-dish",
        "flaticon-open-book",
        "flaticon-high-performance",
        "flaticon-computer",
        "flaticon-project-management",
        "flaticon-stethoscope",
        "flaticon-right-quote",
        "flaticon-call",
        "flaticon-crowdfunding-1",
        "flaticon-investment",
        "flaticon-vector"
    ]
}